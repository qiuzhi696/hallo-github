#include <iostream>
#include <iomanip>
using namespace std;
int main(){
cout<<setw(10)<<"i"<<setw(10)<<"i^2"<<setw(10)<<"i^3\n";
  int i;
  for (i=1;i<=4;i++)
  { cout <<setw(10)<<i<<setw(10)<<i*i;
    cout<<setw(10)<<i*i*i<<endl;
  }
}

