#include<iostream>
#include<cstring>
using namespace std;
int
 main(void)
{ int ch=97;
  char str[]="student";
  cout.put(ch)<<endl;
  cout<<char(ch)<<endl;
  cout.write(str,strlen(str))<<endl;
}

