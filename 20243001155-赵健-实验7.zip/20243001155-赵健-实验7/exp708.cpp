#include<iostream>
using namespace std;
class point
{ private:
	float x,y,z;
  public :
    point(float a=0,float b=0,float c=0)
	{ x=a;y=b;z=c;}
    friend ostream &operator<<(ostream &os,point p ) //������������"<<"
	{cout<<"("<<p.x<<","<<p.y<<","<<p.z<<")\n";
      return os;
	}
    friend istream &operator>>(istream &is,point &p)//�����������">>"
	{ cout<<"x=";cin>>p.x;
	  cout<<"y=";cin>>p.y;
	  cout<<"z=";cin>>p.z;
      return is;
	}
 };

int main(void)
{ point p1(4,5,6),p2;
  cin>>p2;
  cout<<p1<<p2<<endl;
}

