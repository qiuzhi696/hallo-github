#include<iostream>
using namespace std;
int main()
{int a=120,b=250;
 double x=256.43l,y=130.125;
 cout.setf(ios::dec|ios::showpos);
 cout<<a<<"  "<<b<<endl;
 cout.setf(ios::hex|ios::showbase);
 cout<<a<<"  "<<b<<endl;
 cout.setf(ios::fixed);
 cout<<x<<"  "<<y<<endl;
 cout.setf(ios::scientific);
 cout<<x<<"  "<<y<<endl;
 cout.unsetf(ios::scientific|ios::showpos);
 cout<<x<<"  "<<y<<endl;
}

