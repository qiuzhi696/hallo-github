#include<iostream>
using namespace std;
int main()
{int a=120,b=250;
 double x=256.43l,y=130.125;
 cout.width(10);
 cout<<a<<"  "<<b<<endl;
 cout<<x<<"  "<<y<<endl;
 cout.width(10); cout<<a;
 cout.width(10); cout<<b<<endl;
 cout.setf(ios::left|ios::showpos);
 cout.width(10); cout<<a;
 cout.width(10); cout<<b<<endl;
}

