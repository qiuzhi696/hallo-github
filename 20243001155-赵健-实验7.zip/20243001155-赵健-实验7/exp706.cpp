#include<iostream>
using namespace std;
int main()
{int a=120,b=250;
 cout.setf(ios::left);
 cout.width(10);
 cout.fill('*'); cout<<a;
 cout.width(10); cout<<b<<endl;
}

